<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
<!-- Add this script tag right before the closing body tag -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const yesButton = document.getElementById('yesButton');
    const flowerImage = document.createElement('img');

    flowerImage.src = 'flowers.png'; // Path to your flowers image
    flowerImage.style.display = 'none'; // Initially hide the image
    flowerImage.alt = 'Flowers';

    yesButton.addEventListener('click', function() {
        flowerImage.style.display = 'block';
        document.body.appendChild(flowerImage);
    });
});
</script>
